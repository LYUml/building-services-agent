Select and author the synthetic water riser using hydraulic and selected Hong Kong rules.

Check the selected IFC against the explicit synthetic clash policy.

Create an editable schematic only after model and clash checks pass.