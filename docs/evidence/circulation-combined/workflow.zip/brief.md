Synthetic example: check sourced thermal transport.

Check scoped Hong Kong water piping rules.

Release the same hydraulic scenario only when both checks pass.