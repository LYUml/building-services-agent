Synthetic scenario: calculate duty and standby pumps separately against the sourced tank target and scoped WSD pack. Both must satisfy the target alone.

Rerun the duty pump using its checked network and curve only after the entire set passes.

Rerun the standby pump using its checked network and curve only after the entire set passes. Physical equipment, controls, drawings and full regulatory acceptance remain pending.