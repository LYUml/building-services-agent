Create and reconcile the synthetic water riser IFC and hydraulic network.

Check the saved coordinated network against selected HVAC water-piping rules.