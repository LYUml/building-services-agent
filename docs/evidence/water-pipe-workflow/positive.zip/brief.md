Check synthetic HVAC water piping using the selected Hong Kong pack.

Execute the same network only after the selected checks pass.