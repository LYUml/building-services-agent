Run both synthetic design-day lighting variants with actual EnergyPlus.

Check both executed native models against the selected Hong Kong design-condition pack.

Review remaining HVAC clauses and actual project applicability after supported checks pass.