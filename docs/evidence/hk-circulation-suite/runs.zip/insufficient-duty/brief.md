Synthetic demonstration: verify sourced thermal transport targets.

Check scoped Hong Kong air-conditioning water pipe rules.

Release the same hydraulic scenario only after both checks pass.

Review actual fluid conditions, equipment heat transfer, IFC correspondence, controls and complete engineering acceptance.