Author synthetic chilled-water IFC.

Derive the hydraulic network from saved geometry.

Check thermal transport and scoped Hong Kong pipe rules using the inherited native network.

Review full engineering acceptance, physical products and visual evidence.